

<?php
/*Datos de conexion a la base de datos*/
$db_host = "sql8.main-hosting.eu.";
$db_user = "u644738137_alito";
$db_pass = "SZ17eSOr8Jn1Lv441";
$db_name = "u644738137_fas2";
 
$conexion= new mysqli($db_host, $db_user, $db_pass, $db_name); 
if($conexion -> connect_errno){
	die("Fallo la conexion:(".$conexion -> mysqli_connect_errno().")".$conexion-> mysqli_connect_error());
}
?>

