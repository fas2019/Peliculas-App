<header>
  <a href="/php-login"></a>
  <input type='image' src='logo.png' align="center"  width='650' height='450'>

</header>
